import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Dimensions,
  Alert,
  Platform,
  Image,
  Animated,
  Modal,
} from 'react-native';
import * as Location from 'expo-location';
import { MapPin, Navigation, Clock, User, Star, Car, Menu, Bell, ArrowUpDown, Plus, Chrome as Home, X, ChevronRight, ArrowLeft, Search } from 'lucide-react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MapView, Marker } from '@/components/MapView';

const { width, height } = Dimensions.get('window');

interface Driver {
  id: string;
  name: string;
  rating: number;
  vehicle: string;
  plateNumber: string;
  eta: number;
  fare: number;
  location: {
    latitude: number;
    longitude: number;
  };
  photo: string;
  rideType: string;
}

const mockDrivers: Driver[] = [
  {
    id: '1',
    name: 'Rajesh Kumar',
    rating: 4.9,
    vehicle: 'Maruti Swift',
    plateNumber: 'DL-01-AB-1234',
    eta: 3,
    fare: 125.50,
    location: { latitude: 37.7849, longitude: -122.4094 },
    photo: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    rideType: 'mini',
  },
  {
    id: '2',
    name: 'Priya Sharma',
    rating: 4.8,
    vehicle: 'Hyundai i20',
    plateNumber: 'MH-02-CD-5678',
    eta: 5,
    fare: 117.75,
    location: { latitude: 37.7749, longitude: -122.4194 },
    photo: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    rideType: 'mini',
  },
  {
    id: '3',
    name: 'Vikram Singh',
    rating: 4.7,
    vehicle: 'Tata Nexon',
    plateNumber: 'KA-03-EF-9012',
    eta: 7,
    fare: 135.25,
    location: { latitude: 37.7649, longitude: -122.4294 },
    photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    rideType: 'sedan',
  },
  {
    id: '4',
    name: 'Amit Gupta',
    rating: 4.6,
    vehicle: 'Bajaj Auto',
    plateNumber: 'UP-14-XY-7890',
    eta: 2,
    fare: 85.00,
    location: { latitude: 37.7549, longitude: -122.4394 },
    photo: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    rideType: 'auto',
  },
  {
    id: '5',
    name: 'Rohit Sharma',
    rating: 4.9,
    vehicle: 'Honda Activa',
    plateNumber: 'DL-08-BC-4567',
    eta: 1,
    fare: 45.00,
    location: { latitude: 37.7449, longitude: -122.4494 },
    photo: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    rideType: 'bike',
  },
];

const rideTypes = [
  { id: 'auto', name: 'Auto', icon: '🛺', price: 85, time: '2-5 min' },
  { id: 'bike', name: 'Bike', icon: '🏍️', price: 45, time: '1-3 min' },
  { id: 'mini', name: 'Mini', icon: '🚗', price: 125, time: '3-7 min' },
  { id: 'sedan', name: 'Sedan', icon: '🚙', price: 185, time: '5-10 min' },
];

const recentPlaces = [
  { id: '1', name: 'Home', address: 'Sector 18, Noida', icon: '🏠' },
  { id: '2', name: 'Office', address: 'Cyber City, Gurgaon', icon: '🏢' },
  { id: '3', name: 'Airport', address: 'IGI Airport, Delhi', icon: '✈️' },
  { id: '4', name: 'Mall', address: 'Select City Walk, Saket', icon: '🛍️' },
];

const suggestedPlaces = [
  { id: '1', name: 'Connaught Place', address: 'Central Delhi, New Delhi', type: 'popular' },
  { id: '2', name: 'India Gate', address: 'Rajpath, New Delhi', type: 'popular' },
  { id: '3', name: 'Red Fort', address: 'Netaji Subhash Marg, Delhi', type: 'popular' },
  { id: '4', name: 'Lotus Temple', address: 'Bahapur, New Delhi', type: 'popular' },
  { id: '5', name: 'Qutub Minar', address: 'Mehrauli, New Delhi', type: 'popular' },
];

export default function HomeScreen() {
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [pickup, setPickup] = useState('');
  const [destination, setDestination] = useState('');
  const [showRideOptions, setShowRideOptions] = useState(false);
  const [selectedRideType, setSelectedRideType] = useState('mini');
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
  const [rideStatus, setRideStatus] = useState<'idle' | 'searching' | 'found' | 'riding'>('idle');
  const [showMenu, setShowMenu] = useState(false);
  const [showLocationInput, setShowLocationInput] = useState<'pickup' | 'destination' | null>(null);
  const slideAnim = useRef(new Animated.Value(-width * 0.8)).current;

  useEffect(() => {
    if (Platform.OS !== 'web') {
      (async () => {
        let { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
          Alert.alert('Permission Denied', 'Permission to access location was denied');
          return;
        }

        let location = await Location.getCurrentPositionAsync({});
        setLocation(location);
      })();
    }
  }, []);

  useEffect(() => {
    Animated.timing(slideAnim, {
      toValue: showMenu ? 0 : -width * 0.8,
      duration: 300,
      useNativeDriver: true,
    }).start();
  }, [showMenu]);

  const handleRideRequest = () => {
    if (!pickup || !destination) {
      Alert.alert('Missing Information', 'Please enter both pickup and destination locations');
      return;
    }
    setShowRideOptions(true);
    setRideStatus('searching');
    
    setTimeout(() => {
      setRideStatus('found');
    }, 2000);
  };

  const selectDriver = (driver: Driver) => {
    setSelectedDriver(driver);
    setRideStatus('riding');
    setShowRideOptions(false);
    Alert.alert('Ride Confirmed', `${driver.name} is on the way!`);
  };

  const toggleMenu = () => {
    setShowMenu(!showMenu);
  };

  // Filter drivers based on selected ride type
  const filteredDrivers = mockDrivers.filter(driver => driver.rideType === selectedRideType);

  const getRideTypeIcon = (rideType: string) => {
    const type = rideTypes.find(t => t.id === rideType);
    return type ? type.icon : '🚗';
  };

  const renderDriverOption = (driver: Driver) => (
    <TouchableOpacity
      key={driver.id}
      style={styles.driverCard}
      onPress={() => selectDriver(driver)}
    >
      <View style={styles.driverImageContainer}>
        <Image source={{ uri: driver.photo }} style={styles.driverImage} />
        <View style={styles.ratingBadge}>
          <Star size={10} color="#FFFFFF" fill="#FFFFFF" />
          <Text style={styles.ratingBadgeText}>{driver.rating}</Text>
        </View>
      </View>
      
      <View style={styles.driverInfo}>
        <Text style={styles.driverName}>{driver.name}</Text>
        <View style={styles.vehicleRow}>
          <Text style={styles.vehicleIcon}>{getRideTypeIcon(driver.rideType)}</Text>
          <Text style={styles.vehicleText}>{driver.vehicle}</Text>
          <Text style={styles.plateText}>• {driver.plateNumber}</Text>
        </View>
        <View style={styles.etaRow}>
          <Clock size={14} color="#10B981" />
          <Text style={styles.etaText}>{driver.eta} min away</Text>
        </View>
      </View>
      
      <View style={styles.fareContainer}>
        <Text style={styles.fareAmount}>₹{driver.fare}</Text>
        <Text style={styles.fareLabel}>Total</Text>
      </View>
    </TouchableOpacity>
  );

  const renderRideType = (type: any) => (
    <TouchableOpacity
      key={type.id}
      style={[
        styles.rideTypeCard,
        selectedRideType === type.id && styles.selectedRideType
      ]}
      onPress={() => setSelectedRideType(type.id)}
    >
      <Text style={styles.rideTypeIcon}>{type.icon}</Text>
      <Text style={styles.rideTypeName}>{type.name}</Text>
      <Text style={styles.rideTypePrice}>₹{type.price}</Text>
      <Text style={styles.rideTypeTime}>{type.time}</Text>
    </TouchableOpacity>
  );

  const renderMenuItem = (icon: React.ReactNode, title: string, onPress: () => void) => (
    <TouchableOpacity style={styles.menuItem} onPress={onPress}>
      <View style={styles.menuItemIcon}>{icon}</View>
      <Text style={styles.menuItemText}>{title}</Text>
      <ChevronRight size={20} color="#9CA3AF" />
    </TouchableOpacity>
  );

  const renderLocationInput = () => {
    if (!showLocationInput) return null;

    const isPickup = showLocationInput === 'pickup';
    const currentValue = isPickup ? pickup : destination;
    const placeholder = isPickup ? 'Enter pickup location' : 'Enter destination';

    return (
      <Modal
        visible={true}
        animationType="slide"
        onRequestClose={() => setShowLocationInput(null)}
      >
        <SafeAreaView style={styles.fullScreenContainer}>
          <View style={styles.locationInputHeader}>
            <TouchableOpacity 
              style={styles.backButton}
              onPress={() => setShowLocationInput(null)}
            >
              <ArrowLeft size={24} color="#111827" />
            </TouchableOpacity>
            <Text style={styles.locationInputTitle}>
              {isPickup ? 'Pickup Location' : 'Destination'}
            </Text>
            <View style={styles.backButton} />
          </View>

          <View style={styles.searchInputContainer}>
            <View style={styles.searchInputWrapper}>
              <Search size={20} color="#6B7280" />
              <TextInput
                style={styles.searchInput}
                placeholder={placeholder}
                placeholderTextColor="#9CA3AF"
                value={currentValue}
                onChangeText={(text) => {
                  if (isPickup) {
                    setPickup(text);
                  } else {
                    setDestination(text);
                  }
                }}
                autoFocus
              />
            </View>
          </View>

          <ScrollView style={styles.suggestionsContainer}>
            <View style={styles.suggestionSection}>
              <Text style={styles.suggestionSectionTitle}>Recent places</Text>
              {recentPlaces.map((place) => (
                <TouchableOpacity
                  key={place.id}
                  style={styles.suggestionItem}
                  onPress={() => {
                    if (isPickup) {
                      setPickup(place.address);
                    } else {
                      setDestination(place.address);
                    }
                    setShowLocationInput(null);
                  }}
                >
                  <View style={styles.suggestionIcon}>
                    <Text style={styles.suggestionEmoji}>{place.icon}</Text>
                  </View>
                  <View style={styles.suggestionText}>
                    <Text style={styles.suggestionName}>{place.name}</Text>
                    <Text style={styles.suggestionAddress}>{place.address}</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.suggestionSection}>
              <Text style={styles.suggestionSectionTitle}>Popular places</Text>
              {suggestedPlaces.map((place) => (
                <TouchableOpacity
                  key={place.id}
                  style={styles.suggestionItem}
                  onPress={() => {
                    if (isPickup) {
                      setPickup(place.address);
                    } else {
                      setDestination(place.address);
                    }
                    setShowLocationInput(null);
                  }}
                >
                  <View style={styles.suggestionIcon}>
                    <MapPin size={20} color="#6B7280" />
                  </View>
                  <View style={styles.suggestionText}>
                    <Text style={styles.suggestionName}>{place.name}</Text>
                    <Text style={styles.suggestionAddress}>{place.address}</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    );
  };

  const mapProps = Platform.OS !== 'web' ? {
    provider: 'google' as any,
    region: {
      latitude: location?.coords.latitude || 37.7749,
      longitude: location?.coords.longitude || -122.4194,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    },
    showsUserLocation: true,
    showsMyLocationButton: true,
  } : {};

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.menuButton} onPress={toggleMenu}>
          <Menu size={24} color="#111827" />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>Good morning!</Text>
          <Text style={styles.headerSubtitle}>Where are you going?</Text>
        </View>
        <TouchableOpacity style={styles.notificationButton}>
          <Bell size={24} color="#111827" />
          <View style={styles.notificationDot} />
        </TouchableOpacity>
      </View>

      {/* Map Container */}
      <View style={styles.mapContainer}>
        <MapView style={styles.map} {...mapProps}>
          {filteredDrivers.map((driver) => (
            <Marker
              key={driver.id}
              coordinate={driver.location}
              title={driver.name}
              description={`${driver.vehicle} • ${driver.eta} min away`}
            >
              <View style={styles.driverMarker}>
                <Text style={styles.driverMarkerIcon}>{getRideTypeIcon(driver.rideType)}</Text>
              </View>
            </Marker>
          ))}
        </MapView>
      </View>

      {/* Bottom Search Container */}
      <View style={styles.bottomSearchContainer}>
        <View style={styles.searchCard}>
          <View style={styles.locationInputs}>
            <TouchableOpacity 
              style={styles.inputRow}
              onPress={() => setShowLocationInput('pickup')}
            >
              <View style={styles.locationDot} />
              <Text style={[styles.locationInputText, !pickup && styles.placeholderText]}>
                {pickup || 'Pickup location'}
              </Text>
            </TouchableOpacity>
            
            <View style={styles.inputDivider}>
              <View style={styles.dividerLine} />
              <TouchableOpacity style={styles.swapButton}>
                <ArrowUpDown size={16} color="#6B7280" />
              </TouchableOpacity>
              <View style={styles.dividerLine} />
            </View>
            
            <TouchableOpacity 
              style={styles.inputRow}
              onPress={() => setShowLocationInput('destination')}
            >
              <View style={[styles.locationDot, styles.destinationDot]} />
              <Text style={[styles.locationInputText, !destination && styles.placeholderText]}>
                {destination || 'Where to?'}
              </Text>
              <TouchableOpacity style={styles.addStopButton}>
                <Plus size={16} color="#2563EB" />
              </TouchableOpacity>
            </TouchableOpacity>
          </View>

          {/* Recent Places */}
          <View style={styles.recentPlaces}>
            <Text style={styles.recentTitle}>Recent places</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {recentPlaces.map((place) => (
                <TouchableOpacity key={place.id} style={styles.recentPlace}>
                  <Text style={styles.recentPlaceIcon}>{place.icon}</Text>
                  <Text style={styles.recentPlaceName}>{place.name}</Text>
                  <Text style={styles.recentPlaceAddress}>{place.address}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          <TouchableOpacity
            style={[
              styles.searchButton,
              (!pickup || !destination) && styles.searchButtonDisabled
            ]}
            onPress={handleRideRequest}
            disabled={rideStatus !== 'idle' || !pickup || !destination}
          >
            <Text style={styles.searchButtonText}>
              {rideStatus === 'idle' && 'Find a ride'}
              {rideStatus === 'searching' && 'Finding Drivers...'}
              {rideStatus === 'found' && 'Drivers Found'}
              {rideStatus === 'riding' && 'Ride in Progress'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Side Menu */}
      <Modal
        visible={showMenu}
        transparent={true}
        animationType="none"
        onRequestClose={() => setShowMenu(false)}
      >
        <View style={styles.menuOverlay}>
          <TouchableOpacity 
            style={styles.menuBackdrop} 
            onPress={() => setShowMenu(false)}
          />
          <Animated.View 
            style={[
              styles.menuContainer,
              { transform: [{ translateX: slideAnim }] }
            ]}
          >
            <View style={styles.menuHeader}>
              <View style={styles.userProfile}>
                <Image 
                  source={{ uri: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2' }} 
                  style={styles.userAvatar} 
                />
                <View style={styles.userInfo}>
                  <Text style={styles.userName}>Arjun Patel</Text>
                  <Text style={styles.userEmail}>arjun.patel@example.com</Text>
                </View>
              </View>
              <TouchableOpacity style={styles.closeButton} onPress={() => setShowMenu(false)}>
                <X size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            <View style={styles.menuContent}>
              {renderMenuItem(
                <Home size={24} color="#2563EB" />,
                'Home',
                () => {
                  setShowMenu(false);
                  // Navigate to home
                }
              )}
              {renderMenuItem(
                <Clock size={24} color="#10B981" />,
                'Recent Trips',
                () => {
                  setShowMenu(false);
                  // Navigate to recent trips
                }
              )}
              {renderMenuItem(
                <User size={24} color="#8B5CF6" />,
                'Profile',
                () => {
                  setShowMenu(false);
                  // Navigate to profile
                }
              )}
              {renderMenuItem(
                <MapPin size={24} color="#F59E0B" />,
                'Saved Places',
                () => {
                  setShowMenu(false);
                  // Navigate to saved places
                }
              )}
            </View>
          </Animated.View>
        </View>
      </Modal>

      {/* Full-Screen Location Input */}
      {renderLocationInput()}

      {/* Ride Options Bottom Sheet */}
      {showRideOptions && (
        <View style={styles.bottomSheet}>
          <View style={styles.bottomSheetHandle} />
          
          {/* Ride Types */}
          <View style={styles.rideTypesSection}>
            <Text style={styles.sectionTitle}>Choose a ride</Text>
            <ScrollView 
              horizontal 
              showsHorizontalScrollIndicator={false}
              style={styles.rideTypesScroll}
            >
              {rideTypes.map(renderRideType)}
            </ScrollView>
          </View>

          {/* Available Drivers */}
          <View style={styles.driversSection}>
            <Text style={styles.sectionTitle}>
              Available drivers ({filteredDrivers.length})
            </Text>
            <ScrollView style={styles.driversList}>
              {filteredDrivers.length > 0 ? (
                filteredDrivers.map(renderDriverOption)
              ) : (
                <View style={styles.noDriversContainer}>
                  <Text style={styles.noDriversText}>
                    No drivers available for {rideTypes.find(t => t.id === selectedRideType)?.name}
                  </Text>
                  <Text style={styles.noDriversSubtext}>
                    Try selecting a different ride type
                  </Text>
                </View>
              )}
            </ScrollView>
          </View>
        </View>
      )}

      {/* Ride Status Bar */}
      {selectedDriver && (
        <View style={styles.rideStatusBar}>
          <View style={styles.statusDriverInfo}>
            <Image source={{ uri: selectedDriver.photo }} style={styles.statusDriverImage} />
            <View style={styles.statusTextContainer}>
              <Text style={styles.statusTitle}>Your driver is arriving</Text>
              <Text style={styles.statusSubtitle}>
                {selectedDriver.name} • {selectedDriver.vehicle}
              </Text>
              <Text style={styles.statusEta}>{selectedDriver.eta} min away</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.callButton}>
            <Text style={styles.callButtonText}>Call</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  menuButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 2,
  },
  notificationButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  notificationDot: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#EF4444',
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    width: '100%',
    height: '100%',
  },
  driverMarker: {
    backgroundColor: '#2563EB',
    borderRadius: 20,
    padding: 8,
    borderWidth: 3,
    borderColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  driverMarkerIcon: {
    fontSize: 16,
  },
  bottomSearchContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'transparent',
  },
  searchCard: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
    paddingBottom: 40,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  locationInputs: {
    marginBottom: 16,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  locationDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#10B981',
    marginRight: 16,
  },
  destinationDot: {
    backgroundColor: '#EF4444',
  },
  locationInputText: {
    flex: 1,
    fontSize: 16,
    color: '#111827',
    fontWeight: '500',
  },
  placeholderText: {
    color: '#9CA3AF',
  },
  addStopButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#EBF4FF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputDivider: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 28,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#E5E7EB',
  },
  swapButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  recentPlaces: {
    marginBottom: 16,
  },
  recentTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 12,
  },
  recentPlace: {
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    padding: 12,
    marginRight: 12,
    width: 120,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  recentPlaceIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  recentPlaceName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  recentPlaceAddress: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
  },
  searchButton: {
    backgroundColor: '#2563EB',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchButtonDisabled: {
    backgroundColor: '#9CA3AF',
  },
  searchButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  fullScreenContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  locationInputHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
  },
  locationInputTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
  },
  searchInputContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  searchInputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#111827',
    marginLeft: 12,
  },
  suggestionsContainer: {
    flex: 1,
  },
  suggestionSection: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  suggestionSectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 16,
  },
  suggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F8FAFC',
  },
  suggestionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  suggestionEmoji: {
    fontSize: 20,
  },
  suggestionText: {
    flex: 1,
  },
  suggestionName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  suggestionAddress: {
    fontSize: 14,
    color: '#6B7280',
  },
  menuOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    flexDirection: 'row',
  },
  menuBackdrop: {
    flex: 1,
  },
  menuContainer: {
    width: width * 0.8,
    backgroundColor: '#FFFFFF',
    height: '100%',
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 0 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 8,
  },
  menuHeader: {
    backgroundColor: '#2563EB',
    padding: 20,
    paddingTop: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  userProfile: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  userAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 12,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  userEmail: {
    fontSize: 14,
    color: '#DBEAFE',
    marginTop: 2,
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuContent: {
    flex: 1,
    paddingTop: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  menuItemIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  menuItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '500',
    color: '#111827',
  },
  bottomSheet: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 12,
    maxHeight: height * 0.7,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  bottomSheetHandle: {
    width: 40,
    height: 4,
    backgroundColor: '#D1D5DB',
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 20,
  },
  rideTypesSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 16,
  },
  rideTypesScroll: {
    marginHorizontal: -20,
    paddingHorizontal: 20,
  },
  rideTypeCard: {
    width: 100,
    padding: 16,
    marginRight: 12,
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedRideType: {
    backgroundColor: '#EBF4FF',
    borderColor: '#2563EB',
  },
  rideTypeIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  rideTypeName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  rideTypePrice: {
    fontSize: 16,
    fontWeight: '700',
    color: '#2563EB',
    marginBottom: 2,
  },
  rideTypeTime: {
    fontSize: 12,
    color: '#6B7280',
  },
  driversSection: {
    paddingHorizontal: 20,
    flex: 1,
  },
  driversList: {
    flex: 1,
  },
  driverCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  driverImageContainer: {
    position: 'relative',
    marginRight: 16,
  },
  driverImage: {
    width: 56,
    height: 56,
    borderRadius: 28,
  },
  ratingBadge: {
    position: 'absolute',
    bottom: -4,
    right: -4,
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingHorizontal: 6,
    paddingVertical: 2,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  ratingBadgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
    marginLeft: 2,
  },
  driverInfo: {
    flex: 1,
  },
  driverName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  vehicleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  vehicleIcon: {
    fontSize: 16,
    marginRight: 6,
  },
  vehicleText: {
    fontSize: 14,
    color: '#6B7280',
  },
  plateText: {
    fontSize: 14,
    color: '#9CA3AF',
    marginLeft: 4,
  },
  etaRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  etaText: {
    fontSize: 14,
    color: '#10B981',
    fontWeight: '500',
    marginLeft: 6,
  },
  fareContainer: {
    alignItems: 'flex-end',
  },
  fareAmount: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 2,
  },
  fareLabel: {
    fontSize: 12,
    color: '#6B7280',
  },
  noDriversContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  noDriversText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6B7280',
    marginBottom: 8,
  },
  noDriversSubtext: {
    fontSize: 14,
    color: '#9CA3AF',
  },
  rideStatusBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 8,
  },
  statusDriverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  statusDriverImage: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 16,
  },
  statusTextContainer: {
    flex: 1,
  },
  statusTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  statusSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 2,
  },
  statusEta: {
    fontSize: 12,
    color: '#10B981',
    fontWeight: '500',
    marginTop: 2,
  },
  callButton: {
    backgroundColor: '#2563EB',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
  },
  callButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
});