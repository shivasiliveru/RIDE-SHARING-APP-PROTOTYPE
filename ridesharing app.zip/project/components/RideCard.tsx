import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MapPin, Navigation, Calendar, Clock, Star } from 'lucide-react-native';

interface RideCardProps {
  ride: {
    id: string;
    date: string;
    time: string;
    pickup: string;
    destination: string;
    driver: string;
    fare: number;
    rating: number;
    status: 'completed' | 'cancelled';
    duration: string;
  };
  onPress?: () => void;
}

export default function RideCard({ ride, onPress }: RideCardProps) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.header}>
        <View style={styles.dateTimeContainer}>
          <Calendar size={16} color="#6B7280" />
          <Text style={styles.dateText}>{ride.date}</Text>
          <Text style={styles.timeText}>{ride.time}</Text>
        </View>
        <View style={[
          styles.statusBadge,
          ride.status === 'completed' ? styles.completedBadge : styles.cancelledBadge
        ]}>
          <Text style={[
            styles.statusText,
            ride.status === 'completed' ? styles.completedText : styles.cancelledText
          ]}>
            {ride.status === 'completed' ? 'Completed' : 'Cancelled'}
          </Text>
        </View>
      </View>

      <View style={styles.routeContainer}>
        <View style={styles.routeItem}>
          <MapPin size={16} color="#10B981" />
          <Text style={styles.locationText} numberOfLines={1}>
            {ride.pickup}
          </Text>
        </View>
        <View style={styles.routeLine} />
        <View style={styles.routeItem}>
          <Navigation size={16} color="#EF4444" />
          <Text style={styles.locationText} numberOfLines={1}>
            {ride.destination}
          </Text>
        </View>
      </View>

      <View style={styles.footer}>
        <Text style={styles.driverName}>Driver: {ride.driver}</Text>
        
        {ride.status === 'completed' && (
          <View style={styles.stats}>
            <View style={styles.statItem}>
              <Clock size={14} color="#6B7280" />
              <Text style={styles.statText}>{ride.duration}</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.currencySymbol}>₹</Text>
              <Text style={styles.fareText}>{ride.fare}</Text>
            </View>
            {ride.rating > 0 && (
              <View style={styles.statItem}>
                <Star size={14} color="#F59E0B" fill="#F59E0B" />
                <Text style={styles.ratingText}>{ride.rating}</Text>
              </View>
            )}
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  dateTimeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dateText: {
    fontSize: 14,
    color: '#374151',
    marginLeft: 6,
  },
  timeText: {
    fontSize: 14,
    color: '#6B7280',
    marginLeft: 8,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  completedBadge: {
    backgroundColor: '#D1FAE5',
  },
  cancelledBadge: {
    backgroundColor: '#FEE2E2',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  completedText: {
    color: '#065F46',
  },
  cancelledText: {
    color: '#991B1B',
  },
  routeContainer: {
    marginBottom: 16,
  },
  routeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  routeLine: {
    width: 1,
    height: 20,
    backgroundColor: '#D1D5DB',
    marginLeft: 8,
    marginBottom: 8,
  },
  locationText: {
    flex: 1,
    fontSize: 16,
    color: '#374151',
    marginLeft: 12,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  driverName: {
    fontSize: 14,
    color: '#6B7280',
  },
  stats: {
    flexDirection: 'row',
    gap: 16,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 14,
    color: '#6B7280',
    marginLeft: 4,
  },
  currencySymbol: {
    fontSize: 14,
    fontWeight: '600',
    color: '#10B981',
    marginLeft: 4,
  },
  fareText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#10B981',
    marginLeft: 2,
  },
  ratingText: {
    fontSize: 14,
    color: '#F59E0B',
    marginLeft: 4,
  },
});