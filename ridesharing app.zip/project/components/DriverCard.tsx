import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { User, Star, Car, Clock } from 'lucide-react-native';
import { Driver } from '@/types/ride';

interface DriverCardProps {
  driver: Driver;
  onSelect: (driver: Driver) => void;
}

export default function DriverCard({ driver, onSelect }: DriverCardProps) {
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={() => onSelect(driver)}
    >
      <View style={styles.driverInfo}>
        <View style={styles.header}>
          <View style={styles.avatar}>
            <User size={24} color="#2563EB" />
          </View>
          <View style={styles.details}>
            <Text style={styles.name}>{driver.name}</Text>
            <View style={styles.ratingContainer}>
              <Star size={14} color="#F59E0B" fill="#F59E0B" />
              <Text style={styles.rating}>{driver.rating}</Text>
            </View>
          </View>
        </View>
        <View style={styles.vehicleInfo}>
          <Car size={16} color="#6B7280" />
          <Text style={styles.vehicleText}>
            {driver.vehicle} • {driver.plateNumber}
          </Text>
        </View>
      </View>
      
      <View style={styles.rideStats}>
        <View style={styles.statItem}>
          <Clock size={16} color="#6B7280" />
          <Text style={styles.statText}>{driver.eta} min</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.currencySymbol}>₹</Text>
          <Text style={styles.fareText}>{driver.fare}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  driverInfo: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  avatar: {
    width: 40,
    height: 40,
    backgroundColor: '#DBEAFE',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  details: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 2,
  },
  rating: {
    fontSize: 14,
    color: '#6B7280',
    marginLeft: 4,
  },
  vehicleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  vehicleText: {
    fontSize: 14,
    color: '#6B7280',
    marginLeft: 6,
  },
  rideStats: {
    alignItems: 'flex-end',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  statText: {
    fontSize: 14,
    color: '#6B7280',
    marginLeft: 4,
  },
  currencySymbol: {
    fontSize: 16,
    fontWeight: '700',
    color: '#10B981',
    marginLeft: 4,
  },
  fareText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#10B981',
    marginLeft: 2,
  },
});