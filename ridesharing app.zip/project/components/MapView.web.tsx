import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

// Web fallback components
const MapComponent = ({ children, style, ...props }: any) => (
  <View style={[styles.webMapContainer, style]}>
    <Text style={styles.webMapText}>Map View (Web Preview)</Text>
    <Text style={styles.webMapSubtext}>
      Maps will work on mobile devices
    </Text>
    {children}
  </View>
);

const MarkerComponent = ({ title, description, children }: any) => (
  <View style={styles.webMarker}>
    <Text style={styles.webMarkerText}>📍</Text>
    {children}
  </View>
);

export const MapView = MapComponent;
export const Marker = MarkerComponent;

const styles = StyleSheet.create({
  webMapContainer: {
    backgroundColor: '#E5E7EB',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    position: 'relative',
  },
  webMapText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 4,
  },
  webMapSubtext: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
  },
  webMarker: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: [{ translateX: -12 }, { translateY: -12 }],
  },
  webMarkerText: {
    fontSize: 24,
  },
});