import React from 'react';
import MapView, { Marker } from 'react-native-maps';

export { MapView, Marker };