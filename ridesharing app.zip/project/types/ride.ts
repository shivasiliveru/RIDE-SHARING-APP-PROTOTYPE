export interface Driver {
  id: string;
  name: string;
  rating: number;
  vehicle: string;
  plateNumber: string;
  eta: number;
  fare: number;
  location: {
    latitude: number;
    longitude: number;
  };
  photo?: string;
  phone?: string;
}

export interface Ride {
  id: string;
  userId: string;
  driverId: string;
  pickup: {
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
  };
  destination: {
    address: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
  };
  status: 'requested' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';
  fare: number;
  estimatedDuration: number;
  actualDuration?: number;
  requestedAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  rating?: number;
  review?: string;
}

export interface RideRequest {
  pickup: string;
  destination: string;
  pickupCoords: {
    latitude: number;
    longitude: number;
  };
  destinationCoords: {
    latitude: number;
    longitude: number;
  };
  rideType: 'standard' | 'premium' | 'shared';
}

export type RideStatus = 'idle' | 'searching' | 'found' | 'riding' | 'completed';

export interface RideEstimate {
  distance: number;
  duration: number;
  fare: number;
  drivers: Driver[];
}